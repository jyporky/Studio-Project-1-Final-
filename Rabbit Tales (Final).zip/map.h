#pragma once
class map
{
public:
	map();
	~map();
	void pmap(int mmap);
};